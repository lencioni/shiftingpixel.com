<?php
/**
	Add These Functions to make our lives easier
**/
if(!function_exists('get_catbynicename'))
{
	function get_catbyname($category_name) 
	{
	global $wpdb;
	
	$cat_id -= 0; 	// force numeric
	$name = $wpdb->get_var('SELECT cat_ID FROM '.$wpdb->categories.' WHERE cat_name="'.$category_name.'"');
	
	return $name;
	}
}

if(!function_exists('get_comment_count'))
{
	function get_comment_count($post_ID)
	{
		global $wpdb;
		return $wpdb->get_var('SELECT count(*) FROM '.$wpdb->comments.' WHERE comment_post_ID = '.$post_ID);
	}
}

if(!function_exists('link_exists'))
{
	function link_exists($linkname)
	{
		global $wpdb;
		return $wpdb->get_var('SELECT link_id FROM '.$wpdb->links.' WHERE link_name = "'.$wpdb->escape($linkname).'"');
	}
}

class pixelpost_import {
	
	function header() 
	{
		echo '<div class="wrap">';
		echo '<h2>'.__('Import Pixelpost').'</h2>';
	}

	function footer() 
	{
		echo '</div>';
	}
	
	function greet() 
	{
		echo '<p>'.__('Howdy! This importer allows you to extract posts from any Pixelpost 1.4.2 into your blog. This has not been tested on other versions of Pixelpost.  Mileage may vary.').'</p>';
		echo '<p>'.__('Your Pixelpost configuration settings are as follows:').'</p>';
		echo '<form action="admin.php?import=pixelpost&amp;step=1" method="post">';
		$this->db_form();
		echo '<input type="submit" name="submit" value="'.__('Import Categories').'" />';
		echo '</form>';
	}
	
	function get_pp_config()
	{
		global $wpdb;
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Categories
		return $ppdb->get_results('SELECT * FROM '.$prefix.'config', ARRAY_A);
	}
	
	function get_pp_cats()
	{
		global $wpdb;
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Categories
		return $ppdb->get_results('SELECT 
										id,
										name
							   		 FROM '.$prefix.'categories', 
									 ARRAY_A);
	}
	
	function get_pp_postcat($post_id)
	{
		global $wpdb;
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Categories
		return $ppdb->get_results("SELECT cat.name 
									FROM {$prefix}pixelpost p
										INNER JOIN {$prefix}categories cat ON cat.id = p.category
									WHERE p.id = '$post_id'", 
									 ARRAY_A);
	}
	
	function get_pp_postcats($post_id)
	{
		global $wpdb;
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Categories
		return $ppdb->get_results("SELECT 
										ca.cat_id,
										c.name
							   		 FROM {$prefix}catassoc ca
										INNER JOIN {$prefix}categories c ON c.id = ca.cat_id
							   		 WHERE ca.image_id = '$post_id'", 
									 ARRAY_A);
	}
	
	function get_pp_posts()
	{
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Posts
		return $ppdb->get_results("SELECT 
										id,
										datetime,
										headline,
										body,
										image
							   		FROM {$prefix}pixelpost",
							   		ARRAY_A);
	}
	
	function get_pp_post_comment_count($post_id)
	{
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Posts
		return $ppdb->get_results("SELECT count(id) as 'comments_count' FROM {$prefix}comments WHERE parent_id = '$post_id'", ARRAY_A);
	}
	
	function get_pp_comments()
	{
		global $wpdb;
		// General Housekeeping
		$ppdb = new wpdb(get_option('ppuser'), get_option('pppass'), get_option('ppname'), get_option('pphost'));
		set_magic_quotes_runtime(0);
		$prefix = get_option('tpre');
		
		// Get Comments
		return $ppdb->get_results('SELECT
										id,
										parent_id,
										datetime,
										ip,
										message,
										name,
										url,
										email
									FROM '.$prefix.'comments',
									ARRAY_A);
	}
	
	function cat2wp($categories='') 
	{
		// General Housekeeping
		global $wpdb;
		$count			= 0;
		$txpcat2wpcat	= array();
		// Do the Magic
		if(is_array($categories))
		{
			echo '<p>'.__('Importing Categories...').'<br /><br /></p>';
			foreach ($categories as $category) 
			{
				$count++;
				extract($category);
				
				// Make Nice Variables
				$name		= $wpdb->escape($name);
				$nicename	= str_replace(' ', '-', strtolower($name));
				
				if($cinfo = category_exists($name))
				{
					$ret_id = wp_insert_category(array('cat_ID' => $cinfo, 'category_nicename' => $nicename, 'cat_name' => $name));
				}
				else
				{
					$ret_id = wp_insert_category(array('category_nicename' => $nicename, 'cat_name' => $name));
				}
				$ppcat2wpcat[$id] = $ret_id;
			}
			
			// Store category translation for future use
			add_option('ppcat2wpcat',$ppcat2wpcat);
			echo '<p>'.sprintf(__('Done! <strong>%1$s</strong> categories imported.'), $count).'<br /><br /></p>';
			return true;
		}
		echo __('No Categories to Import!');
		return false;
	}
	
	function posts2wp($posts='')
	{
		// General Housekeeping
		global $wpdb;
		$count					= 0;
		$ppposts2wpposts		= array();
		$cats					= array();
		$ppconfig				= $this->get_pp_config();

		// Do the Magic
		if(is_array($posts))
		{
			echo '<p>'.__('Importing Posts...').'<br /><br /></p>';
			set_time_limit(0);
			foreach($posts as $post)
			{
				$count++;
				extract($post);
				
				//Can we do this more efficiently?
				$uinfo			= ( get_userdatabylogin( $AuthorID ) ) ? get_userdatabylogin( $AuthorID ) : 1;
				$authorid		= ( is_object( $uinfo ) ) ? $uinfo->ID : $uinfo ;
				
				$cc				= $this->get_pp_post_comment_count($id);
				if (is_array($cc)) {
					$comments_count	= $cc[0]['comments_count'];
				} else {
					$comments_count	= 0;
				}
				
				
				// Import Post data into WordPress
				
				if($pinfo = post_exists($Title,$Body))
				{
					$ret_id = wp_insert_post(array(
							'ID'				=> $pinfo,
							'post_date'			=> $datetime,
							'post_author'		=> $authorid,
							'post_modified'		=> $datetime,
							'post_title'		=> $headline,
							'post_content'		=> $body,
							'post_status'		=> 'publish',
							'comment_status'	=> 'open',
							'comment_count'		=> $comments_count)
							);
				}
				else 
				{
					$ret_id = wp_insert_post(array(
							'post_date'			=> $datetime,
							'post_author'		=> $authorid,
							'post_modified'		=> $datetime,
							'post_title'		=> $headline,
							'post_content'		=> $body,
							'post_status'		=> 'publish',
							'comment_status'	=> 'open',
							'comment_count'		=> $comments_count)
							);
				}
				$ppposts2wpposts[$id]	= $ret_id;
				
				// Make Post-to-Category associations
				$cats 					= array();
				$catCount				= 0;
				
				$category				= $this->get_pp_postcat($id);
				$category				= $category[0]['name'];
				if($cat1 = get_catbyname($category)) { $cats[$catCount] = $cat1; $catCount++; }
				
				$postcats				= $this->get_pp_postcats($id);
				
				foreach($postcats as $postcat)
				{
					if($cat = get_catbyname($postcat['name'])) { $cats[$catCount] = $cat; $catCount++; }
				}

				if(!empty($cats)) { wp_set_post_cats('', $ret_id, $cats); }
				
				// Upload the image
				$uploads 				= wp_upload_dir();
				$oldfile				= $ppconfig[0]['imagepath'] . $image;
				
				$filename				= preg_replace('/^.*?_/', '', $image);
				$file					= $uploads['path'] . '/' . $filename;
				$url					= $uploads['url'] . '/' . $filename;
				
				copy($oldfile, $file);
				
				// Save the data
				$image_id = wp_insert_attachment(array(
						'post_title'		=> $headline,
						'post_content'		=> '',
						'post_status'		=> 'atachment',
						'post_parent'		=> $ret_id,
						'post_mime_type'	=> 'image/jpeg',
						'guid'				=> $url),
					$file,
					$ret_id
						);
						
				// Generate the attachment's postmeta
				$imagesize						= getimagesize($file);
				$imagedata['width']				= $imagesize['0'];
				$imagedata['height']			= $imagesize['1'];
				list($uwidth, $uheight)			= get_udims($imagedata['width'], $imagedata['height']);
				$imagedata['hwstring_small']	= "height='$uheight' width='$uwidth'";
				$imagedata['file']				= $file;
			
				add_post_meta($image_id, '_wp_attachment_metadata', $imagedata);

				if ( $imagedata['width'] * $imagedata['height'] < 3 * 1024 * 1024 ) {
					if ( $imagedata['width'] > 128 && $imagedata['width'] >= $imagedata['height'] * 4 / 3 )
						$thumb				= wp_create_thumbnail($file, 128);
					elseif ( $imagedata['height'] > 96 )
						$thumb				= wp_create_thumbnail($file, 96);
			
					if ( @file_exists($thumb) ) {
						$newdata			= $imagedata;
						$newdata['thumb']	= basename($thumb);
						update_post_meta($image_id, '_wp_attachment_metadata', $newdata, $imagedata);
						echo '.'; // for some reason, thumbnails didn't work until I put this echo here...
					} else {
						$error				= $thumb;
					}
				} // end if
				if ($error) {
					print_r($error);
				}
				
			} // end foreach
			set_time_limit(30);
		}
		// Store ID translation for later use
		add_option('ppposts2wpposts',$ppposts2wpposts);
		
		echo '<p>'.sprintf(__('Done! <strong>%1$s</strong> posts imported.'), $count).'<br /><br /></p>';
		return true;	
	}
	
	function comments2wp($comments='')
	{
		// General Housekeeping
		global $wpdb;
		$count			= 0;
		$ppcm2wpcm		= array();
		$postarr		= get_option('ppposts2wpposts');
		
		// Magic Mojo
		if(is_array($comments))
		{
			echo '<p>'.__('Importing Comments...').'<br /><br /></p>';
			foreach($comments as $comment)
			{
				$count++;
				extract($comment);
				
				// WordPressify Data
				$comment_post_ID	= $postarr[$parent_id];
				$web				= $url;
				
				
				if($cinfo = comment_exists($name, $datetime))
				{
					// Update comments
					$ret_id = wp_update_comment(array(
							'comment_ID'			=> $cinfo,
							'comment_post_ID'		=> $comment_post_ID,
							'comment_author'		=> $name,
							'comment_author_email'	=> $email,
							'comment_author_url'	=> $web,
							'comment_date'			=> $datetime,
							'comment_content'		=> $message,
							'comment_approved'		=> '1')
							);
				}
				else 
				{
					// Insert comments
					$ret_id = wp_insert_comment(array(
							'comment_post_ID'		=> $comment_post_ID,
							'comment_author'		=> $name,
							'comment_author_email'	=> $email,
							'comment_author_url'	=> $web,
							'comment_author_IP'		=> $ip,
							'comment_date'			=> $datetime,
							'comment_content'		=> $message,
							'comment_approved'		=> '1')
							);
				}
				$pppcm2wpcm[$id] = $ret_id;
			}
			// Store Comment ID translation for future use
			add_option('pppcm2wpcm', $pppcm2wpcm);			
			
			// Associate newly formed categories with posts
			get_comment_count($ret_id);
			
			
			echo '<p>'.sprintf(__('Done! <strong>%1$s</strong> comments imported.'), $count).'<br /><br /></p>';
			return true;
		}
		echo __('No Comments to Import!');
		return false;
	}
	
	function db_form()
	{
		echo '<ul>';
		printf('<li><label for="dbuser">%s</label> <input type="text" name="dbuser" /></li>', __('Pixelpost Database User:'));
		printf('<li><label for="dbpass">%s</label> <input type="password" name="dbpass" /></li>', __('Pixelpost Database Password:'));
		printf('<li><label for="dbname">%s</label> <input type="text" name="dbname" /></li>', __('Pixelpost Database Name:'));
		printf('<li><label for="dbhost">%s</label> <input type="text" name="dbhost" value="localhost" /></li>', __('Pixelpost Database Host:'));
		printf('<li><label for="dbpre">%s</label> <input type="text" name="dbpre" value="pixelpost_" /></li>', __('Pixelpost Table Prefix:'));
		echo '</ul>';
	}
	
	
	function import_categories() 
	{	
		// Category Import	
		$cats		= $this->get_pp_cats();
		$this->cat2wp($cats);
		add_option('pp_cats', $cats);
		
		echo '<form action="admin.php?import=pixelpost&amp;step=2" method="post">';
		printf('<input type="submit" name="submit" value="%s" />', __('Import Posts'));
		echo '</form>';

	}
	
	function import_posts()
	{
		// Post Import
		$posts = $this->get_pp_posts();
		$this->posts2wp($posts);
		
		echo '<form action="admin.php?import=pixelpost&amp;step=3" method="post">';
		printf('<input type="submit" name="submit" value="%s" />', __('Import Comments'));
		echo '</form>';
	}
	
	function import_comments()
	{
		// Comment Import
		$comments = $this->get_pp_comments();
		$this->comments2wp($comments);
		
		echo '<form action="admin.php?import=pixelpost&amp;step=4" method="post">';
		printf('<input type="submit" name="submit" value="%s" />', __('Finish'));
		echo '</form>';
	}
	
	function cleanup_ppimport()
	{
		delete_option('tpre');
		delete_option('pp_cats');
		delete_option('ppcat2wpcat');
		delete_option('ppposts2wpposts');
		delete_option('ppcm2wpcm');
		delete_option('ppuser');
		delete_option('pppass');
		delete_option('ppname');
		delete_option('pphost');
		$this->tips();
	}
	
	function tips()
	{
		echo '<p>'.__('Welcome to WordPress.  We hope (and expect!) that you will find this platform incredibly rewarding!').'</p>';
		echo '<h3>'.__('WordPress Resources').'</h3>';
		echo '<p>'.__('Finally, there are numerous WordPress resources around the internet.  Some of them are:').'</p>';
		echo '<ul>';
		echo '<li>'.__('<a href="http://www.wordpress.org">The official WordPress site</a>').'</li>';
		echo '<li>'.__('<a href="http://wordpress.org/support/">The WordPress support forums').'</li>';
		echo '<li>'.__('<a href="http://codex.wordpress.org">The Codex (In other words, the WordPress Bible)</a>').'</li>';
		echo '</ul>';
		echo '<p>'.sprintf(__('That\'s it! What are you waiting for? Go <a href="%1$s">login</a>!'), '/wp-login.php').'</p>';
	}
	
	function dispatch() 
	{

		if (empty ($_GET['step']))
			$step = 0;
		else
			$step = (int) $_GET['step'];
		$this->header();
		
		if ( $step > 0 ) 
		{
			if($_POST['dbuser'])
			{
				if(get_option('ppuser'))
					delete_option('ppuser');	
				add_option('ppuser',$_POST['dbuser']);
			}
			if($_POST['dbpass'])
			{
				if(get_option('pppass'))
					delete_option('pppass');	
				add_option('pppass',$_POST['dbpass']);
			}
			
			if($_POST['dbname'])
			{
				if(get_option('ppname'))
					delete_option('ppname');	
				add_option('ppname',$_POST['dbname']);
			}
			if($_POST['dbhost'])
			{
				if(get_option('pphost'))
					delete_option('pphost');
				add_option('pphost',$_POST['dbhost']); 
			}
			if($_POST['dbpre'])
			{
				if(get_option('tpre'))
					delete_option('tpre');
				add_option('tpre',$_POST['dbpre']); 
			}

		}

		switch ($step) 
		{
			default:
			case 0 :
				$this->greet();
				break;
			case 1 :
				$this->import_categories();
				break;
			case 2 :
				$this->import_posts();
				break;
			case 3 :
				$this->import_comments();
				break;
			case 4 :
				$this->cleanup_ppimport();
				break;
		}
		
		$this->footer();
	}
	
} // end class

$pp_import = new pixelpost_import();
register_importer('pixelpost', 'Pixelpost', __('Import posts from a Pixelpost Blog'), array ($pp_import, 'dispatch'));

?>